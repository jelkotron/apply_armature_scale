Apply Armature Scale

This Blender addon implements a single operator. When applying scale to animated armatures, 
location in animation data needs to considered. 
After installation, "Apply Scale to Animated Armature" can be found in the Object > Apply menu.

